#pragma once

#include "includes.h"
void util_zero(void *, int);
int util_memsearch(char *, int, char *, int);
ipv4_t util_local_addr(void);
